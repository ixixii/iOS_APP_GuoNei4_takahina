//
//  SecondViewController.h
//  takahina
//
//  Created by beyond on 2020/03/27.
//  Copyright © 2020 beyond. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SecondViewController : UIViewController


@end

