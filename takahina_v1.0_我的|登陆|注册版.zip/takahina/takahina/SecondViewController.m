//
//  SecondViewController.m
//  takahina
//
//  Created by beyond on 2020/03/27.
//  Copyright © 2020 beyond. All rights reserved.
//

#import "SecondViewController.h"

@interface SecondViewController ()

@end

@implementation SecondViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}


@end
