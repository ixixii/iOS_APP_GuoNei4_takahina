//
//  TAAboutViewController.m
//  takahina
//
//  Created by beyond on 2020/03/29.
//  Copyright © 2020 beyond. All rights reserved.
//

#import "TAAboutViewController.h"

@interface TAAboutViewController ()

@end

@implementation TAAboutViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    self.title = @"关于我们";
}
@end
